import osmnx as ox
import folium

ox.config(use_cache=True, log_console=True)

# Change if you want to get a single city
# e.g: city = "Berlin"
city = "Kaárst"

# If no city is specified, use the list of cities
cities = [
    "Berlin",
    "Bremen",
    "Büsum",
    "Cochem",
    "Dortmund",
    "Düsseldorf",
    "Essen",
    "Frankfurt am Main",
    "Füssen",
    "Hamburg",
    "Husum",
    "Köln",
    "Kühlungsborn",
    "Leipzig",
    "München",
    "Oberstdorf",
    "Rothenburg ob der Tauber",
    "Rügen",
    "Stuttgart",
    "Sylt",
    "Trier",
    "Winterberg"
]


# No need to change anything below this line

def create_map(mapcity):
    place = mapcity + ", Germany"
    place_types = ["school", "kindergarten", "playground", "pitch"]

    # Define a color for each place type
    colors = {"school": "red", "kindergarten": "orange", "playground": "yellow", "pitch": "green"}

    G = ox.graph_from_place(place, network_type="all_private")

    osmmap = folium.Map(location=[G.nodes[list(G.nodes())[0]]["y"], G.nodes[list(G.nodes())[0]]["x"]], zoom_start=12)

    polygon = ox.geocode_to_gdf(place).unary_union

    # Retrieve the geometries for all place types in one go
    gdfs = [ox.geometries_from_polygon(polygon, tags={"leisure": place_type}) if place_type in ["playground",
                                                                                                "pitch"] else ox.geometries_from_polygon(
        polygon, tags={"amenity": place_type}) for place_type in place_types]

    # Loop over the gdfs and add markers and circles to the map for each geometry
    for gdf, place_type in zip(gdfs, place_types):
        for i, row in gdf.iterrows():
            geom = row["geometry"]
            # Check if the geometry is a point or a polygon
            if geom.type == "Point":
                lat = geom.y
                lng = geom.x
            elif geom.type == "Polygon":
                # Get the centroid of the polygon
                center = geom.centroid
                lat = center.y
                lng = center.x
            folium.Circle([lat, lng], radius=250, color=colors[place_type], fill=True, fill_opacity=0.1).add_to(osmmap)

    # Retrieve pedestrian zones and add them to the map
    pedestrian_zones = ox.geometries_from_polygon(polygon, tags={"highway": "pedestrian"})

    for i, row in pedestrian_zones.iterrows():
        geom = row["geometry"]
        if geom.type == 'Polygon':
            folium.Polygon(locations=[(lat, lon) for lon, lat in geom.exterior.coords], color='blue', fill_color='blue',
                           fill_opacity=0.2).add_to(osmmap)
        elif geom.type == 'MultiPolygon':
            for poly in geom:
                folium.Polygon(locations=[(lat, lon) for lon, lat in poly.exterior.coords], color='blue',
                               fill_color='blue', fill_opacity=0.2).add_to(osmmap)

    # Display the map
    osmmap.save("no-dope-zone/no-dope-zone_" + city + ".html")


if __name__ == "__main__":
    if city:
        create_map(city)
    else:
        for city in cities:
            create_map(city)
